SERVER_HOST = '0.0.0.0'  # Listen on all interfaces
SERVER_PORT = 8443       # Port for VPN server
PROXY_URL = 'http://127.0.0.1:8080'  # Intermediate Proxy Server URL
