SERVER_HOST = '127.0.0.1'  # Use localhost for testing
SERVER_PORT = 8443         # Port of the VPN server
